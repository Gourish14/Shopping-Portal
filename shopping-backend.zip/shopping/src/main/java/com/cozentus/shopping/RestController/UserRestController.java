package com.cozentus.shopping.RestController;

public class UserRestController {
	
}

package com.cozentus.shopping.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cozentus.shopping.Model.Customer;
import com.cozentus.shopping.Model.User;
import com.cozentus.shopping.Repository.CustomerRepository;
import com.cozentus.shopping.Repository.UserRepository;

@Service
public class CustomerService {

    @Autowired
    private CustomerRepository customerRepository;
    

    @Autowired
    private UserRepository userRepository; 

    public List<Customer> getAllCustomers() {
        return customerRepository.findAll();
    }

    public Customer getCustomerById(Integer customerId) {
        return customerRepository.findById(customerId).orElse(null);
    }

//    public Customer createCustomer(Customer customer) {
//        return customerRepository.save(customer);
//    }

    public void updateCustomer(Integer customerId, Customer updatedCustomer) {
        Customer existingCustomer = customerRepository.findById(customerId).orElse(null);
        if (existingCustomer != null) {
            existingCustomer.setName(updatedCustomer.getName());
            existingCustomer.setEmail(updatedCustomer.getEmail());
            existingCustomer.setPhoneNumber(updatedCustomer.getPhoneNumber());
            existingCustomer.setAddress(updatedCustomer.getAddress());
            customerRepository.save(existingCustomer);
        }
    }

    public void deleteCustomer(Integer customerId) {
        customerRepository.deleteById(customerId);
    }
    

    public Customer createCustomer(Customer customer) {
        // Create a new User entity with email and password fields
        User user = new User();
        user.setUsername(customer.getEmail()); // Store email as username
        user.setPassword(customer.getPhoneNumber()); // Store phone number as password
        user.setRole("ROLE_Customer");
        userRepository.save(user);
        // Save the customer
        customerRepository.save(customer);
        return customer;
    }
}


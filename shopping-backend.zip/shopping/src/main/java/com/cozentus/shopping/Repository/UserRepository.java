package com.cozentus.shopping.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cozentus.shopping.Model.User;

public interface UserRepository extends JpaRepository<User, Integer>{

}

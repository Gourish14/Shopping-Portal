package com.cozentus.shopping.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cozentus.shopping.Model.Category;

@Repository
public interface CategoryRepository extends JpaRepository<Category, Integer> {
}

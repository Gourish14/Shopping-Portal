package com.cozentus.shopping.RestController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.cozentus.shopping.Model.Category;
import com.cozentus.shopping.Service.CategoryService;

@RestController
@CrossOrigin(origins = "*") 
@RequestMapping("/categories")
public class CategoryRestController {

    @Autowired
    private CategoryService categoryService;
    
    @GetMapping("/show/all")
    public List<Category> getAllCategories() {
        return categoryService.getAllCategories();
    }
    
    @GetMapping("/show/{categoryId}")
    public Category getCategoryById(@PathVariable Integer categoryId) {
        return categoryService.getCategoryById(categoryId);
    }
    
    @PostMapping("/add")
    public Category createCategory(@RequestBody Category category) {
        return categoryService.createCategory(category);
    }
    
    @PostMapping("/update/{categoryId}")
    public void updateCategory(@PathVariable Integer categoryId, @RequestBody Category updatedCategory) {
        categoryService.updateCategory(categoryId, updatedCategory);
    }

    @PostMapping("/delete/{categoryId}")
    public void deleteCategory(@PathVariable Integer categoryId) {
        categoryService.deleteCategory(categoryId);
    }
}
